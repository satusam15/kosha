"""Local model routing subsystem."""
