"""ReAct-style agent loop: plan -> call tool -> observe -> iterate.

The loop is a genuine iterate-until-done process (not a single LLM call):

  1. Build a system prompt describing the available tools and the output
     protocol (JSON "actions").
  2. Send the accumulated message history to the locally routed model.
  3. If the model emits an ACTION, execute the tool, append the OBSERVATION,
     and loop again.
  4. When the model emits a FINAL answer (or we hit max iterations), stop.

Everything is local. No external API calls.

TODOs:
  - The parsing in `_extract_action` is deliberately simple (JSON-block
    based). If your local model does not emit clean JSON reliably, tighten
    this or switch to a more robust structured-output strategy.
  - Wire in your own stop-criteria / guardrails as needed.
"""

from __future__ import annotations

import json
import re
import time
from dataclasses import dataclass, field
from typing import Optional

from backend.router.model_router import Route, route_task, stream_chat
from backend.agent.tools import describe_tools, run_tool

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------
MAX_ITERATIONS = 8          # hard cap on tool calls per request
SYSTEM_PREAMBLE = """You are mrpl-workbench, a local, offline-first agentic assistant.

You have access to these tools:
{tools}

Follow this protocol STRICTLY.

To call a tool, emit exactly one JSON block like this, then STOP generating
immediately — do not write "OBSERVATION" yourself, and do not write more than
one ACTION block per turn. The real tool result will be given to you next.

ACTION
{{"tool": "search_docs", "args": {{"query": "safety harness SOP"}}}}
END_ACTION

After the tool runs, the real OBSERVATION will be given to you. Use it to
plan your next step.

When a document gives you a numeric threshold or range, explicitly state the
actual reading, the threshold/range, and whether the reading is above,
below, or inside it, before concluding a risk level. Apply every escalation
rule stated in the SOP text you retrieved (e.g. "increases risk by one
level") -- do not skip a rule just because it is at the end of a passage.

Only use run_code for actual numeric computation you cannot do yourself.
Do NOT use run_code to "generate" a document, report, or approval note --
use generate_deliverable for that once you have gathered the facts you need
(e.g. via ocr_image and/or search_docs). Reason about risk levels and
recommendations yourself in plain text; you do not need code for that.

When you have enough information to answer the user, stop and emit a final
answer as a normal paragraph. Do NOT emit an ACTION block if you are ready to
answer.

You may take up to {max_iter} steps. Be concise but complete.
"""


# ---------------------------------------------------------------------------
# Message log / state
# ---------------------------------------------------------------------------
@dataclass
class AgentStep:
    """A single logged step in the agent trace."""

    kind: str          # "plan" | "action" | "observation" | "final"
    content: str
    tool: Optional[str] = None
    args: Optional[dict] = None
    ts: float = field(default_factory=time.time)


@dataclass
class AgentResult:
    answer: str = ""
    steps: list[AgentStep] = field(default_factory=list)
    iterations: int = 0
    routed: Optional[Route] = None


# ---------------------------------------------------------------------------
# Action extraction (JSON-block based)
# ---------------------------------------------------------------------------
_ACTION_RE = re.compile(
    r"ACTION\s*(\{.*?\})\s*END_ACTION",
    flags=re.DOTALL | re.IGNORECASE,
)


_PY_LITERAL_RE = re.compile(r"\b(True|False|None)\b")
_PY_TO_JSON_LITERAL = {"True": "true", "False": "false", "None": "null"}


def _extract_action(text: str) -> Optional[dict]:
    """Return the first parsed action dict, or None if none present."""
    m = _ACTION_RE.search(text)
    if not m:
        return None
    raw = m.group(1)
    try:
        payload = json.loads(raw)
    except json.JSONDecodeError:
        # Small models often mix in Python literals (True/False/None) inside
        # otherwise-valid JSON. Retry once with those swapped before giving up.
        try:
            payload = json.loads(_PY_LITERAL_RE.sub(lambda m: _PY_TO_JSON_LITERAL[m.group(0)], raw))
        except json.JSONDecodeError:
            return None
    if not isinstance(payload, dict) or "tool" not in payload:
        return None
    payload.setdefault("args", {})
    return payload


# ---------------------------------------------------------------------------
# The loop
# ---------------------------------------------------------------------------
def run_agent(
    user_message: str,
    *,
    has_upload: bool = False,
    history: Optional[list[dict]] = None,
    max_iterations: int = MAX_ITERATIONS,
) -> AgentResult:
    """Run the ReAct loop on a user message and return the final answer.

    Args:
        user_message: the user's request.
        has_upload: True if an image/file was attached (routes to vision).
        history: optional prior messages to keep context across turns.
        max_iterations: safety cap on tool calls.
    """
    route = route_task(user_message, has_upload=has_upload)
    result = AgentResult(routed=route, iterations=0)

    messages: list[dict] = list(history or [])
    if not messages or messages[0].get("role") != "system":
        messages.insert(
            0,
            {
                "role": "system",
                "content": SYSTEM_PREAMBLE.format(
                    tools=describe_tools(), max_iter=max_iterations
                ),
            },
        )
    messages.append({"role": "user", "content": user_message})

    last_action_signature: Optional[str] = None
    repeat_count = 0

    for iteration in range(max_iterations):
        result.iterations = iteration + 1

        # --- PLAN: stream the model's response ---
        plan_parts: list[str] = []
        for chunk in stream_chat(route.model, messages):
            plan_parts.append(chunk)
        plan = "".join(plan_parts).strip()

        # Store a compact plan trace (avoid storing the full model text twice).
        result.steps.append(AgentStep(kind="plan", content=plan[:2000]))

        action = _extract_action(plan)
        if action is None:
            # The model answered without needing a tool -> we are done.
            result.steps.append(AgentStep(kind="final", content=plan))
            result.answer = plan
            return result

        tool_name = action["tool"]
        args = action.get("args", {})
        args_json = json.dumps(args, default=str)
        result.steps.append(
            AgentStep(kind="action", content=f"{tool_name}({args_json})",
                      tool=tool_name, args=args)
        )

        # --- ACT + OBSERVE ---
        observation = run_tool(tool_name, args_json)
        result.steps.append(AgentStep(kind="observation", content=observation[:2000]))

        # Greedy decoding is deterministic: if the exact same call is retried
        # after failing, it will just fail identically forever. Detect that
        # and force a course change instead of burning the rest of the loop.
        signature = f"{tool_name}:{args_json}"
        repeat_count = repeat_count + 1 if signature == last_action_signature else 0
        last_action_signature = signature

        nudge = ""
        if repeat_count >= 1:
            nudge = (
                "\n\nYou already called this exact tool with these exact "
                "arguments and it failed. Repeating it will fail the same "
                "way again. Do NOT call it again — either try a different "
                "tool/approach, or if you already have enough information, "
                "give your final answer or call generate_deliverable now."
            )

        # Feed the observation back into the conversation and loop again.
        messages.append(
            {"role": "assistant", "content": plan[:2000]}
        )
        messages.append(
            {
                "role": "user",
                "content": f"OBSERVATION:\n{observation}\n\n"
                           "Continue. If you are done, give your final answer. "
                           f"Otherwise emit your next ACTION block.{nudge}",
            }
        )

    # Loop exhausted without an explicit final answer.
    result.answer = (
        f"[stopped] reached max iterations ({max_iterations}) before a final "
        "answer. Last model text was appended to the trace."
    )
    return result
