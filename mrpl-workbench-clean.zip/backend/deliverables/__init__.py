"""Deliverable generation: schemas + renderers."""
