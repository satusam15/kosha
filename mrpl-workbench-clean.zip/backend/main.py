"""FastAPI app tying the mrpl-workbench backend together.

All model calls go to local Ollama at `http://localhost:11434`; all docs
come from the local RAG index; code runs in the local Docker sandbox. No
external API calls anywhere.

Endpoints:
    POST /chat                 run the agent loop on a message
    GET  /network/stats        live outbound-connection count (offline watchdog)
    GET  /health               backend + Ollama reachability
    POST /index/build          build/rebuild the RAG index from data/sops
    GET  /retrieve             quick RAG retrieval for debugging
    GET  /sandbox              sandbox health
    GET  /ocr?path=...         extract text from an image / scanned pdf
"""

from __future__ import annotations

import os
from pathlib import Path

import ollama
from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

from backend.agent.loop import run_agent
from backend.router.model_router import OLLAMA_BASE_URL, REASONING_MODEL
from backend import network_monitor

app = FastAPI(title="mrpl-workbench", version="0.1.0")

# Allow the (any-origin, local) frontend to talk to this API. Still offline.
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

DATA_DIR = Path(__file__).resolve().parents[1] / "data"


# ---------------------------------------------------------------------------
# Request/response models
# ---------------------------------------------------------------------------
class ChatRequest(BaseModel):
    message: str
    has_upload: bool = False


class ChatResponse(BaseModel):
    answer: str
    model: str
    task_type: str
    iterations: int
    steps: list[dict]


class BuildIndexResponse(BaseModel):
    ok: bool
    detail: dict


# ---------------------------------------------------------------------------
# Health
# ---------------------------------------------------------------------------
@app.get("/health")
def health():
    ollama_ok = False
    try:
            client = ollama.Client(host=OLLAMA_BASE_URL)
            client.list()
            ollama_ok = True
    except Exception:  # noqa: BLE001
            ollama_ok = False
    return {
        "status": "ok",
        "ollama": ollama_ok,
        "ollama_url": OLLAMA_BASE_URL,
        "default_model": REASONING_MODEL,
        "offline_only": True,
    }


# ---------------------------------------------------------------------------
# Chat (agent loop)
# ---------------------------------------------------------------------------
@app.post("/chat", response_model=ChatResponse)
def chat(req: ChatRequest):
    if not req.message.strip():
        raise HTTPException(status_code=400, detail="message is empty")

    try:
        result = run_agent(req.message, has_upload=req.has_upload)
    except Exception as exc:  # noqa: BLE001 - surface Ollama outage cleanly
        raise HTTPException(
            status_code=503,
            detail=(
                f"Could not reach the local model backend (Ollama at "
                f"localhost:11434). Is it running? Original error: {exc}"
            ),
        ) from exc

    steps = [
        {"kind": s.kind, "content": s.content, "tool": s.tool}
        for s in result.steps
    ]
    return ChatResponse(
        answer=result.answer,
        model=result.routed.model if result.routed else "unknown",
        task_type=result.routed.task_type if result.routed else "unknown",
        iterations=result.iterations,
        steps=steps,
    )


# ---------------------------------------------------------------------------
# Network / offline watchdog
# ---------------------------------------------------------------------------
@app.get("/network/stats")
def network_stats():
    return network_monitor.network_stats()


@app.get("/network/count")
def network_count():
    return {"outbound_nonlocal": network_monitor.outbound_nonlocal_count()}


# ---------------------------------------------------------------------------
# RAG
# ---------------------------------------------------------------------------
@app.post("/index/build", response_model=BuildIndexResponse)
def build_index():
    try:
        from backend.rag.index import build_index as _build

        detail = _build()
        return BuildIndexResponse(ok=True, detail=detail)
    except Exception as exc:  # noqa: BLE001
        raise HTTPException(status_code=500, detail=str(exc)) from exc


@app.get("/retrieve")
def retrieve(q: str = Query(..., min_length=1), top_k: int = 3):
    try:
        from backend.rag.retrieve import retrieve as _retrieve

        return {"hits": _retrieve(q, top_k=top_k)}
    except Exception as exc:  # noqa: BLE001
        raise HTTPException(status_code=500, detail=str(exc)) from exc


# ---------------------------------------------------------------------------
# Sandbox health
# ---------------------------------------------------------------------------
@app.get("/sandbox")
def sandbox_health():
    from backend.sandbox.executor import check_sandbox_health

    return check_sandbox_health()


# ---------------------------------------------------------------------------
# OCR / vision
# ---------------------------------------------------------------------------
@app.get("/ocr")
def ocr(path: str = Query(..., description="local path to an image or scanned PDF")):
    from backend.agent.tools import _safe_repo_path

    # CORS is wide open (allow_origins=["*"]) for local frontend convenience,
    # which means any site open in the user's browser could otherwise GET
    # this endpoint with an arbitrary path and exfiltrate OCR'd content from
    # any image file on disk. Restrict to the repo root, same as the agent's
    # own ocr_image tool.
    try:
        p = _safe_repo_path(path)
    except PermissionError as exc:
        raise HTTPException(status_code=403, detail=str(exc)) from exc
    if not p.exists():
        raise HTTPException(status_code=404, detail=f"file not found: {path}")
    from backend.ocr.vision import ocr_image, ocr_pdf

    if p.suffix.lower() == ".pdf":
        return {"text": ocr_pdf(p)}
    return {"text": ocr_image(p)}


# ---------------------------------------------------------------------------
# Serve the frontend (3-pane chat UI) as static files at the site root,
# so the browser talks to /chat, /network/*, /ocr etc. same-origin (offline).
# ---------------------------------------------------------------------------
FRONTEND_DIR = Path(__file__).resolve().parents[1] / "frontend"


@app.get("/")
def index():
    return FileResponse(str(FRONTEND_DIR / "index.html"))


if FRONTEND_DIR.exists():
    app.mount("/", StaticFiles(directory=str(FRONTEND_DIR), html=True), name="frontend")


if __name__ == "__main__":
    import uvicorn

    # TODO: bind host 0.0.0.0 only if you want the LAN to reach it; for a
    # purely local workbench, 127.0.0.1 is the offline-safe default.
    uvicorn.run(app, host=os.getenv("MRPL_HOST", "127.0.0.1"), port=8000)
